CMS Style Pack Template (v1)
============================

1. Edit cms-theme.json + extra.css.
2. Re-zip with files at the ARCHIVE ROOT.
3. Import in Appearance → Customize.

Not a WordPress PHP theme.
