Manly
=====

Oak, iron, leather theme pack (dark lodge / magazine).

1. Edit cms-theme.json + extra.css as needed.
2. Re-zip with files at the ARCHIVE ROOT.
3. Import in Appearance → Customize.

Not a WordPress PHP theme.
