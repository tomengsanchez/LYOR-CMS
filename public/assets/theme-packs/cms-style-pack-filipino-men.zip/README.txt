The Filipino Men
================

Warm paper journal for everyday Filipino manhood. Editorial chrome, magazine essays.

1. Edit cms-theme.json + extra.css as needed.
2. Re-zip with files at the ARCHIVE ROOT.
3. Import in Appearance → Customize.

Seed chrome (no post import): php cli/seed_filipino_men_site.php

Not a WordPress PHP theme.
